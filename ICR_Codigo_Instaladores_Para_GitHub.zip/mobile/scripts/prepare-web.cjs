'use strict';
// El paquete móvil lleva el código web local, pero sigue usando el mismo Supabase.
// No se modifica el sitio publicado en Render ni se duplica la base de datos.
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');
const output = path.resolve(__dirname, '../www');
const files = [
  'index.html', 'app.js', 'config.js', 'history-file.js',
  'receipt-pdf.js', 'styles.css', 'icon-192.png', 'icon-512.png'
];
fs.mkdirSync(output, { recursive: true });
for (const name of files) {
  const source = path.join(root, name);
  if (!fs.existsSync(source)) throw Error(`Falta ${source}`);
  fs.copyFileSync(source, path.join(output, name));
}
const htmlPath = path.join(output, 'index.html');
let html = fs.readFileSync(htmlPath, 'utf8');
html = html.replace(/^\s*<link rel="manifest"[^>]*>\s*$/m, '');
html = html.replace(/^\s*<script src="\.\/install-pwa\.js[^>]*><\/script>\s*$/m, '');
html = html.replace('</body>', '  <script src="./native-download.js"></script>\n</body>');
// En las apps instaladas no mostrar el asistente de instalación de la PWA.
if (/install-pwa\.js/.test(html)) throw Error('No se pudo retirar el asistente PWA del HTML móvil.');
fs.writeFileSync(htmlPath, html);
fs.copyFileSync(path.join(root, 'mobile', 'native-download.js'), path.join(output, 'native-download.js'));
const appPath = path.join(output, 'app.js');
let js = fs.readFileSync(appPath,'utf8');
const registration = "if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});";
if (!js.includes(registration)) throw Error('Revisar la inscripción del Service Worker en app.js');
js = js.replace(registration,'/* Sin Service Worker dentro de la aplicación móvil nativa. */');
const legacyDownload = "function downloadBlob(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1800)}";
if (!js.includes(legacyDownload)) throw Error('Revisar función de exportación de Excel en app.js');
js = js.replace(legacyDownload, "function downloadBlob(blob,name){if(window.Capacitor?.isNativePlatform?.()){window.icrNativeDownloadBlob(blob,name).catch(e=>{console.error(e);toast('No se pudo guardar el archivo: '+e.message,true)});return;}const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1800)}");
fs.writeFileSync(appPath, js);
const pdfPath = path.join(output, 'receipt-pdf.js');
let pdf = fs.readFileSync(pdfPath,'utf8');
const pdfLine = ' const url=URL.createObjectURL(blob),a=document.createElement(\'a\');';
if (!pdf.includes(pdfLine)) throw Error('Revisar generación de archivos PDF en receipt-pdf.js');
pdf=pdf.replace(pdfLine, " if(window.Capacitor?.isNativePlatform?.()){window.icrNativeDownloadBlob(blob,\`Salida_\${deliveryFolio(data.id)}.pdf\`).catch(e=>{console.error(e);alert('No se pudo guardar el PDF: '+e.message)});return;}\n"+pdfLine);
fs.writeFileSync(pdfPath,pdf);
console.log(`Listos ${files.length} archivos web para Android/iOS en ${output}`);
