/* Puente de archivos para la versión nativa. No se carga en la web normal. */
(() => {
  'use strict';
  function safeName(name) {
    return String(name || 'reporte.xlsx')
      .replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/^\.+/, '')
      .slice(0, 140) || 'reporte.xlsx';
  }

  async function blobBase64(blob) {
    const buf = new Uint8Array(await blob.arrayBuffer());
    const strings = [];
    for (let i = 0; i < buf.length; i += 8192) {
      strings.push(String.fromCharCode(...buf.subarray(i, i + 8192)));
    }
    return btoa(strings.join(''));
  }

  window.icrNativeDownloadBlob = async (blob, filename) => {
    const p = window.Capacitor?.Plugins;
    if (!window.Capacitor?.isNativePlatform?.() || !p?.Filesystem || !p?.Share) {
      throw new Error('No están disponibles los permisos nativos para guardar archivos.');
    }
    const file = await p.Filesystem.writeFile({
      path: 'Informes/' + safeName(filename),
      data: await blobBase64(blob),
      directory: 'CACHE',
      recursive: true
    });
    await p.Share.share({
      title: 'Guardar o compartir reporte',
      files: [file.uri],
      dialogTitle: 'Guardar reporte de Insumos Central Retiros'
    });
  };
})();
