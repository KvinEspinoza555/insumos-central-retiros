'use strict';

const { app, BrowserWindow, Menu, shell, session } = require('electron');
const path = require('node:path');

const APP_URL = 'https://insumos-central-retiros.onrender.com/';
const ALLOWED_ORIGIN = new URL(APP_URL).origin;

function isAppUrl(raw) {
  try {
    const value = new URL(raw);
    return value.protocol === 'https:' && value.origin === ALLOWED_ORIGIN;
  } catch (_) { return false; }
}

function openSafeExternal(raw) {
  try {
    const url = new URL(raw);
    if (url.protocol === 'https:' || url.protocol === 'mailto:') {
      void shell.openExternal(url.toString()).catch(() => {});
    }
  } catch (_) { /* No abrir URL inválidas */ }
}

let mainWindow;

function createWindow() {
  const win = new BrowserWindow({
    width: 1380,
    height: 850,
    minWidth: 820,
    minHeight: 540,
    backgroundColor: '#F7F7FA',
    autoHideMenuBar: true,
    title: 'Insumos Central Retiros',
    icon: path.join(__dirname, 'assets', 'icon-512.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      devTools: false,
      spellcheck: true
    }
  });
  mainWindow = win;
  win.webContents.setWindowOpenHandler(({ url }) => {
    // La app imprime comprobantes abriendo una ventana vacía y escribiendo el PDF/HTML.
    if (url === 'about:blank' || url === '') {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          autoHideMenuBar: true,
          title: 'Imprimir · Insumos Central Retiros',
          webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            sandbox: true,
            webSecurity: true
          }
        }
      };
    }
    openSafeExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (!isAppUrl(url)) {
      event.preventDefault();
      openSafeExternal(url);
    }
  });
  win.webContents.on('will-redirect', (event, url) => {
    if (!isAppUrl(url)) {
      event.preventDefault();
      openSafeExternal(url);
    }
  });
  win.webContents.on('did-fail-load', (_event, code, detail, url, isMainFrame) => {
    if (!isMainFrame || !isAppUrl(url)) return;
    win.setTitle('Sin conexión · Insumos Central Retiros');
    console.error('No se pudo cargar la aplicación:', code, detail);
  });
  win.webContents.on('did-finish-load', () => {
    win.setTitle('Insumos Central Retiros');
  });
  void win.loadURL(APP_URL);
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (!mainWindow) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  });

  app.whenReady().then(() => {
    // Solo permisos explícitamente necesarios; la aplicación funciona sin cámara ni ubicación.
    session.defaultSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { label: 'Archivo', submenu: [{ role: 'quit', label: 'Salir' }] },
      { label: 'Ver', submenu: [
        { label: 'Actualizar', accelerator: 'CmdOrCtrl+R', click: () => mainWindow?.webContents.reload() },
        { label: 'Ampliar', role: 'zoomIn' },
        { label: 'Reducir', role: 'zoomOut' },
        { label: 'Tamaño normal', role: 'resetZoom' },
        { label: 'Pantalla completa', role: 'togglefullscreen' }
      ] }
    ]));
    createWindow();
    app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
  });

  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
