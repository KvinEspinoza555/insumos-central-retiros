# Insumos Central Retiros · aplicaciones instalables

Esta entrega incluye la **web v2.4** (los 13 archivos que ya existían) más el proyecto para generar:

- **Windows:** `Insumos-Central-Retiros-Setup-1.0.0.exe` (instalador NSIS con escritorio y menú Inicio).
- **Android:** `app-debug.apk` (paquete de PRUEBAS, instalable manualmente en Android).
- **iPhone/iPad:** estructura para crear un proyecto nativo iOS con Capacitor; exige un Mac con Xcode y firma de Apple para distribuirlo. **No incluye una IPA firmada**.

**Estado importante:** el ZIP contiene el **código preparado**, no instaladores compilados. El `.exe` y el `.apk` se generan al ejecutar manualmente la acción GitHub descrita abajo. No se ha ejecutado esa compilación desde este entorno.

## Qué ocurre con los datos

- **No se instala una segunda base de datos.** Todas las plataformas acceden al mismo Supabase de Insumos Central Retiros con los mismos permisos, ID y PIN.
- No se tocan ni borran usuarios, clientes, insumos, inventario ni historial de 693 entregas. No se requieren migraciones SQL.
- La **versión Windows** carga siempre la versión actual de `https://insumos-central-retiros.onrender.com/` dentro de una ventana de escritorio, por lo que se actualiza cuando publicas cambios en la web.
- **Android/iOS** contienen los archivos web locales de la versión instalada. Para recibir mejoras del diseño hay que generar una actualización APK/IPA; los datos de Supabase se mantienen sincronizados en línea.
- Necesitas Internet para operar con Supabase. No es una app que funcione íntegramente sin conexión.
- En Android/iOS, las exportaciones de Excel y PDF se preparan para mostrarse en el menú nativo **Guardar o compartir** mediante los plugins `Filesystem` y `Share`. Esta integración todavía requiere pruebas reales en dispositivos.

## Cómo preparar GitHub por primera vez

1. Descomprime el ZIP en el computador.
2. Abre tu repositorio `KvinEspinoza555/insumos-central-retiros` usando **GitHub Desktop** (recomendado por la presencia de carpetas y archivos ocultos).
3. Copia el **contenido** de la carpeta descomprimida en la raíz del repositorio local, conservando los directorios `desktop`, `mobile` y `.github/workflows`. También hay 13 archivos del sitio web (v2.4) que se actualizarán. **No subas el ZIP sin extraer ni metas todos los archivos dentro de una carpeta adicional.**
4. Confirma los cambios (Commit) y pulsa **Push origin**. Render podrá publicar la versión web cuando llegue el commit, como siempre. La compilación nativa NO se ejecuta automáticamente.
5. En GitHub abre la pestaña **Actions** → **Compilar instaladores Windows y Android** → **Run workflow** → **Run workflow**.
6. Cuando ambos trabajos aparezcan en verde, abre la ejecución y busca **Artifacts**:
   - `Insumos-Central-Retiros-Windows-EXE` → descarga ZIP y extrae el `.exe`.
   - `Insumos-Central-Retiros-Android-APK-PRUEBAS` → descarga ZIP y extrae `app-debug.apk`.
7. Instala el EXE en Windows. En Android, transfiere el APK al teléfono y permite esa instalación manual solo si confías en el archivo. Conserva un respaldo de los instaladores generados: GitHub conserva estos artefactos solo 14 días por defecto en esta configuración.

**Si prefieres compilar Windows en tu propio PC (sin GitHub Actions):** instala Node.js 22 y ejecuta en `desktop`: `npm install` y luego `npm run dist:win`. Encontrarás el EXE en `desktop/dist`.

**Advertencia Windows:** como aún no hay certificado de firma de código de la aplicación, Windows SmartScreen puede mostrar «Editor desconocido». No recomendamos distribuir un instalador sin firma a terceros sin gestionar primero una firma y un proceso de seguridad.

**Advertencia Android:** el `app-debug.apk` está firmado con una clave de desarrollo generada en la compilación y es solo para pruebas. Para distribuir versiones confiables y actualizables de forma permanente hay que crear un APK de producción con una clave de firma propia, guardada fuera de GitHub y respaldada con seguridad, y probar el ciclo de actualización. No publicar el debug en Play Store.

## iPhone/iPad — aplicación verdaderamente nativa

Para hacer una app iOS distribuible a otras personas:

1. En un **Mac** con Xcode compatible, instala Node.js 22+.
2. En la carpeta `mobile`, ejecuta estos comandos:

   ```bash
   npm install
   npm run prepare:web
   npx cap add ios
   npx cap sync ios
   npx cap open ios
   ```

3. En Xcode configura el Bundle ID de la aplicación y la firma de Apple de tu equipo.
4. Prueba el inicio de sesión y todas las operaciones de inventario, subida de Excel, exportaciones y PDF.
5. Para TestFlight o App Store, usa un Apple Developer Program válido. Apple cobra normalmente **US$99 por año**. La aprobación por Apple **no está garantizada**; una app basada principalmente en contenido web puede requerir mayor funcionalidad nativa. Un iPhone **no instala APK ni EXE**.

Mientras no uses firma y distribución iOS, la alternativa gratuita para iPhone es la PWA existente «Agregar a inicio» desde Safari, que puede abrirse a pantalla completa pero **no equivale a una distribución nativa App Store**.

## Costos y controles

- Los workflows se ejecutan **solo de forma manual** para evitar gastar minutos de GitHub Actions de forma accidental; revisa los límites de minutos, tus presupuestos de GitHub y las políticas de facturación antes de ejecutarlos.
- La compilación no contrata servidores, no cambia el plan de Supabase ni Render y no requiere claves privadas en el repositorio.
- No agregues a GitHub archivos `.jks`, `.keystore`, certificados de Apple ni claves `service_role` de Supabase.

## Estructura

```
app.js, index.html, styles.css ...  ← misma web v2.4 publicada en Render
desktop/main.cjs                  ← ventana protegida de escritorio Electron
desktop/package.json             ← versión y configuración instalador Windows
desktop/assets/icon.ico         ← icono Windows
mobile/capacitor.config.json     ← identificador y parámetros Android/iOS
mobile/scripts/prepare-web.cjs   ← prepara web embebida para la app móvil
mobile/native-download.js         ← compartir Excel/PDF desde Android/iOS
mobile/package.json             ← dependencias de Capacitor
.github/workflows/compilar-instaladores.yml  ← compilación MANUAL en GitHub
```

## Pruebas realizadas en esta entrega

- Se validaron los scripts de Node.js con `node --check`.
- Se ejecutó el preparador de archivos móviles y se comprobó que elimina el aviso de PWA dentro de las apps nativas y adapta las exportaciones de Excel/PDF al menú nativo para compartir, sin cambiar el código del sitio web original. El puente de compartir fue comprobado con plugins simulados, no en hardware real.
- Se verificó el contenido y estructura del ZIP.
- **No se ha generado ni probado un ejecutable Windows, APK ni IPA**: necesitan Windows/Android SDK/Xcode o una ejecución de CI para compilarse. Antes de uso operativo real hay que probar las instalaciones e inicio de sesión en un dispositivo.
